import pkg_resources
import constant
import docx
import class_grabberV2
import txt_file_validator
import doc_file_validator
import file_validator_director
import os.path
import output_injection
import loader
from array import *


class Interpreter(object):
    file = ''
    file_contents = []
    my_classes = []
    str = ''
    rel = []
    fin = ''
    partner = ''
    output = []
    attrib_types = []

    def __init__(self, file):
        self.file = file
        self.dict = {}
        self.output = []

    def data_parser(self):
        count = 0
        class_count = 0
        temp_str = ''
        for line in self.file_contents:

            if 'class' in line and '{\n':
                temp = line.split(' ')
                self.my_classes.append(temp[1])
                class_count += 1
                count = 1
                continue
            elif '}\t\n' in line or '}\n' in line:
                count = 0

            self.dictionary_inject(count=count, line=line, classes=self.my_classes, class_count=class_count)

        return self.dict

    def dictionary_inject(self, count, line, classes, class_count):

        tempr = ''
        if count == 1:
            self.fin += line;
        else:
            self.dict[classes[class_count-1]] = self.fin
            self.fin = ''

    def load(self):
        name, separator, extension = self.file.partition(".")
        if extension == "txt":
            file_validate = txt_file_validator.TxtFileValidator(new_file=self.file)
            call_director = file_validator_director.FVDirector(file_validate)
            if call_director.validate():
                load = loader.Loader(self.file)
                self.file_contents = load.load_file()
                self.data_parser()
                self.rel = load.relArr
                self.get_details()
            else:
                raise Exception("Incorrect File")
        elif extension == "docx":
            file_validate = doc_file_validator.DocFileValidator(new_file=self.file)
            call_director = file_validator_director.FVDirector(file_validate)
            if call_director.validate():
                load = loader.Loader(self.file)
                self.file_contents = load.load_file()
                self.data_parser()
                self.rel = load.relArr
                self.get_details()
            else:
                raise Exception("Incorrect File")

        else:
            raise Exception("File Not Supported, only .docx, .doc, and .txt")



    def process_rel(self, class_name):

        has_rel = False
        self.partner = ''

        for x in self.rel:
            tempx = x.split(" ")
            if class_name == tempx[2]:
                self.partner = tempx[0]
                has_rel = True
                break
            else:
                has_rel = False

        return has_rel

    def get_details(self):

        for x, y in self.dict.items():

            a_class = class_grabberV2.ClassGrabber(new_class_name=x, new_data=y)
            output_in = output_injection.OutputInjection()
            test = self.process_rel(a_class.class_name.replace("{", ""))
            class_header = "class " + a_class.class_name.replace("{", ":")

            output_in.class_header(array=self.output, test=test, partner=self.partner, class_name=a_class.class_name)

            for line in a_class.attrib:
                output_in.attrib_type(array=self.output, attrib=line)
            for line in a_class.methods:
                output_in.method_returns(array=self.output, method=line, method_to_run=a_class.check_ret(method=line))

            self.output.append("# =========================================================================\n")

        return self.output


