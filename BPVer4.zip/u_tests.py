import txt_file_validator
import class_grabberV2
import interpreterV5
import output_injection
import loader
import unittest


class RefactoredTest(unittest.TestCase):

    # def setUp(self):
    #
    # def tearDown(self):

    def fv_test1(self):
        self.assertTrue(txt_file_validator.TxtFileValidator("some.txt").file_extension_check())

    def fv_test2(self):
        input = "READ.txt"
        x = txt_file_validator.TxtFileValidator(input)
        self.assertTrue(x.check_plant())

    def append_details_attrib_test(self):
        input = "myPlayer"
        expected = ['my_Player']
        x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="()")
        x.append_details(array_to_append=x.attrib, detail_to_append=input)
        self.asssertEquals(x.attrib, expected)

    def append_details_methods_test(self):
        input = "myPlayer"
        expected = ['my_Player']
        x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="()")
        x.append_details(array_to_append=x.methods, detail_to_append=input)
        self.asssertEquals(x.methods, expected)

    def add_under_test(self):
        input = "getBlock()"
        expected = 'get_Block()'
        x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="()")
        self.assertEquals(x.add_under(input), expected)

    def check_ret_test(self):
        input = "int getWall()"
        expected = False
        x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="()")
        self.assertTrue(x.check_ret(input))

    def check_is_upper_test(self):
        input_val = "G"
        input_ind = 1
        expected = '_G'
        x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="()")
        self.assertEquals(x.check_is_upper(index=input_ind, value=input_val))

    def attrib_type_test(self):
        input = "int row"

        output = []
        expected = ""
        x = output_injection.OutputInjection()
        x.attrib_type(array=output,attrib=input)
        for data in output:
            expected = data.replace("\t\t", "")
        self.assertEquals(expected, 'self.row = 0')

    def attrib_type_test(self):
        input = "int getRow"

        output = []
        result = ""
        expected = 'def get_row -> int: pass'
        grab = class_grabberV2.ClassGrabber(new_class_name="", new_data="")
        x = output_injection.OutputInjection()
        x.method_returns(array=output, method=grab.add_under(n=input), method_to_run=grab.check_ret(method=input))
        for data in output:
            result = data.replace("\t", "").replace("\n", "")
        self.assertEquals(result, 'self.row = 0')

    def parse_uneeded_test(self):
        input = "@enduml"

        x = loader.Loader(file="")
        self.assertTrue(x.parse_uneeded(line=input))

    def get_rel_test(self):
        input = "Tester *-- Toaster"

        x = loader.Loader(file="")
        self.assertTrue(x.get_rel(line=input))

if __name__ == '__main__':
    unittest.main(verbosity=2)