import abstract_class_builder


class BuildConcretes(abstract_class_builder.ClassBuilder):

    def __init__(self, inheritor):
        super().__init__()
        self.inherit_target = inheritor
        self.methods = ''

    def get_details(self, data):
        self.data = data
        self.get_class_name()

    def get_class_name(self):
        temp = self.data.split("{")
        for line in temp:
            if "class" in line:
                cls = line.find("(")
                spc = line.find(" ")
                self.class_name = line[spc:cls]

    def get_methods(self, data):
        self.methods = data
        self.data += self.methods

    def create_methods(self, methods_data):
        meth = methods_data.replace("\n\t\tpass\n\n\t", "\n\t\t# do something\n\n\t")
        meth = meth.replace("()", "(self)")
        self.result += meth

    def read(self):
        count = 0
        self.result += "import %s" % self.inherit_target
        temp = self.data.split("\n\t")
        for line in temp:
            if "__init__" in line:
                self.result += line.replace("\n\n", "\n\t\tsuper().__init__()\n\n\n")
            elif "->" in line:
                self.create_methods(line)
            else:
                self.result += line + "\n\n\t"








        # count = 0
        # for line in self.data:
        #     if count == 1:
        #         self.file.write(line)
        #     else:
        #         if "class" in line:
        #             temp = line.split(" ")
        #             self.create_class(temp[1])
        #             self.file.write(line)
        #         elif "__init__" in line:
        #             self.create_constructor(line)
        #             count = 1
        #         elif line == '\n':
        #             count = 0
        #         elif "()" in line:
        #             self.create_methods(line)
        #             self.file.write("\t# Code that the method implements")
