from abc import ABCMeta, abstractmethod


class ClassBuilder(metaclass=ABCMeta):

    def __init__(self):
        self.data = ''
        self.result = ''
        self.class_name = ''

    @abstractmethod
    def get_details(self, data):
        pass

    @abstractmethod
    def get_class_name(self):
        pass

    @abstractmethod
    def create_methods(self, methods_data):
        pass

    @abstractmethod
    def read(self):
        pass

    def get_result(self):
        return self.result