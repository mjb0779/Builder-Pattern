class ClassGrabber(object):
    x = ""
    details = []
    class_name = ""
    methods = []
    attrib = []
    para = []
    return_val = ""
    ret = False

    def __init__(self, new_class_name, new_data):
        self.class_name = new_class_name
        self.details = new_data
        self.get_details()

    def get_details(self):
        self.methods = []
        self.attrib = []
        temp = self.details.split("\n\t" and "\t" and "\n")

        for line in temp:

            if "(" in line and ")" in line:
                self.append_details(array_to_append=self.methods, detail_to_append=line.replace("\t", ""))
            else:
                self.append_details(array_to_append=self.attrib, detail_to_append=line.replace("\t", ""))

        return self.attrib, self.methods

    def append_details(self, array_to_append, detail_to_append):
        array_to_append.append(self.add_under(n=detail_to_append))

    def add_under(self, n):

        self.x = ''
        arr = list(n)
        temp = []
        for inx, item in enumerate(arr):

            temp.append(self.check_is_upper(index=inx, value=item))

        self.x = self.x.join(temp)
        return self.x

    def check_is_upper(self, index, value):

        output = ""
        if index == 0 and value.isupper():
           output = value.lower()
        elif value.isupper():
           output = "_" + value
        else:
           output =  value

        return output

    def check_ret(self, method):

        x = method.split(" ")
        if "(" in x[0]:
            self.ret = False
        else:
            self.ret = True

        return self.ret
