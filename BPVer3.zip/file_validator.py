import os.path


class FileValidator(object):

    file = ''

    def __init__(self, new_file):
        self.file = new_file

    def file_extension_check(self):
        (file_holder, file_extension) = os.path.splitext(self.file)

        if file_extension != '.txt':
            return False
        return True

    def check_plant(self):
        try:
            with open(self.file, "r") as file:
                contents = file.read()
                if '@startuml' in contents or '@enduml' in contents:
                    return True
                else:
                    raise Exception("File is not of PlantUML setting")

        except FileNotFoundError:
            raise Exception("File Does not Exist")

    def check(self):
        if self.check_plant():
            if self.file_extension_check():
                return True
            else:
                return False

        return False