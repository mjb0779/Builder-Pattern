import abstract_class_builder

class BuildConcretes(abstract_class_builder.ClassBuilder):

    def __init__(self):
        super().__init__()
        self.inherit_target = ''

    def get_details(self, data):
        self.data = data
        self.get_class_name()
        self.get_inheritance()

    def get_class_name(self):
        temp = self.data.split("{")
        for line in temp:
            if "class" in line:
                cls = line.split(" ")
                self.class_name = cls[1]

    def get_inheritance(self):
        temp = self.class_name.split("(")
        inherit = temp[1]
        self.inherit_target = inherit.replace("}", "")


    def create_methods(self, methods_data):
        self.file.write(methods_data)

    def read(self):









        # count = 0
        # for line in self.data:
        #     if count == 1:
        #         self.file.write(line)
        #     else:
        #         if "class" in line:
        #             temp = line.split(" ")
        #             self.create_class(temp[1])
        #             self.file.write(line)
        #         elif "__init__" in line:
        #             self.create_constructor(line)
        #             count = 1
        #         elif line == '\n':
        #             count = 0
        #         elif "()" in line:
        #             self.create_methods(line)
        #             self.file.write("\t# Code that the method implements")

