from abc import ABCMeta, abstractmethod


class ClassBuilder(metaclass=ABCMeta):

    def __init__(self):
        self.data = ''
        self.result = ''
        self.class_name = ''

    def get_details(self, data):
        pass

    def get_class_name(self):
        pass

    def create_methods(self, methods_data):
        pass

    def read(self):
        pass

    def get_result(self):
        return self.result