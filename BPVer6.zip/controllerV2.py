import interpreter
import interpreterV5
import my_view
import Director
import build_abstruct_class
import build_concrete_class


class Controller:

    def __init__(self, file):
        self.view = my_view.View()
        self.x = file
        self.output = []
        self.abstract_dictionary = {}
        self.go()

    def go(self):
        load = interpreterV5.Interpreter(self.x)
        load.load()
        temp = ''
        for item in load.output:
            temp += item

        self.output = temp.split("# =========================================================================")

    def parse_data(self):
        for line in self.output:
            if "(metaclass=ABCMeta)" in line :
                self.view.say(">> Abstract Class")
                abs = build_abstruct_class.BuildAbstructs()
                director = Director.Director(builder=abs, file=line)
                director.give_details()
                director.build()
                self.add_abstract_methods(abs.class_name, abs.object_methods)
                self.view.say(abs.get_result())
            elif line == "\n" or "":
                continue
            else:
                self.view.say(">>> Concrete Class")
                i = line.find("(")
                x = line.find(")")
                inherit = line[i + 1:x]
                conc = build_concrete_class.BuildConcretes(inherit)
                director = Director.Director(builder=conc, file=line)
                director.give_details()
                # getting data from abstract
                conc.get_methods(self.get_inheritor_details(conc.inherit_target))
                director.build()
                self.view.say(conc.get_result())

    def get_inheritor_details(self, inheritor):
        data = ''
        for x in self.abstract_dictionary:
            if x == inheritor:
                data = self.abstract_dictionary.get(x)
        return data

    def add_abstract_methods(self, key, data):
        self.abstract_dictionary[key] = data

