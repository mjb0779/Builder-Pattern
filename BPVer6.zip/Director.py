import controllerV2


class Director(object):

    def __init__(self, builder, file):
        self.data = file
        self.builder = builder

    def set_builder(self, new_builder):
        self.builder = new_builder

    def give_details(self):
        self.builder.get_details(self.data)

    def build(self):
        self.builder.read()
