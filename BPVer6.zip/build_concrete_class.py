import abstract_class_builder


class BuildConcretes(abstract_class_builder.ClassBuilder):

    def __init__(self, inheritor):
        super().__init__()
        self.inherit_target = inheritor
        self.methods = ''

    def get_details(self, data):
        self.data = data
        self.get_class_name()

    def get_class_name(self):
        temp = self.data.split("{")
        for line in temp:
            if "class" in line:
                cls = line.find("(")
                spc = line.find(" ")
                self.class_name = line[spc:cls]

    def get_methods(self, data):
        self.methods = data
        self.data += self.methods

    def create_methods(self, methods_data):
        meth = methods_data.replace("\t\tpass", "\t# do something\n\n")
        meth = meth.replace("()", "(self)")
        self.result += meth

    def read(self):
        count = 0
        self.result += "import %s\n\n" % self.inherit_target
        temp = self.data.split("\n")
        for line in temp:
            if "__init__" in line:
                self.result += "\n" + line + "\n\t\tsuper().__init__()\n\n\t"
            elif "pass" in line:
                self.create_methods(line)
            elif line == "":
                continue
            else:
                self.result += line + "\n\t"
