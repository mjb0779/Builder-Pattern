

class FVContext(object):

    def __init__(self, validator):
        self.validator = validator

    def set_validator(self, new_validator):
        self.validator = new_validator

    def validate(self):
        return self.validator.check()
