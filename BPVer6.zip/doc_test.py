import doctest
import txt_file_validator
import class_grabberV2
import interpreterV5
import output_injection
import loader


def fv_test1(n):

    """
    >>> fv_test1('some.txt')
    True
    >>> fv_test1('thing.txt')
    True
    >>> fv_test1('else')
    False
    >>> fv_test1('man')
    False
    >>> fv_test1('sad.txt')
    True
    """

    return txt_file_validator.TxtFileValidator(n).file_extension_check()


def fv_test2(n):

    """
    >>> fv_test2("READ.txt")
    True
    >>> fv_test2("Text.txt")
    Traceback (most recent call last):
    ...
    Exception: File is not of PlantUML setting
    >>> fv_test2("somewhere.txt")
    Traceback (most recent call last):
    ...
    Exception: File Does not Exist
    >>> fv_test2("Test 2.txt")
    True
    >>> fv_test2("READ ME.txt")
    Traceback (most recent call last):
    ...
    Exception: File is not of PlantUML setting
    """

    x = txt_file_validator.TxtFileValidator(n)
    return x.check_plant()

# REFACTORING TESTS
# CLASS_GRABBER TEST


def append_details_attrib_test(n):
    # Doc test for class_grabber.get_attrib()
    """
    >>> append_details_attrib_test("myPlayer")
    ['my_Player']
    >>> append_details_attrib_test("allMyFiles")
    ['all_My_Files']
    >>> append_details_attrib_test("reverseOutput")
    ['reverse_Output']
    >>> append_details_attrib_test("toyBox")
    ['toy_Box']
    >>> append_details_attrib_test("allMyToybox")
    ['all_My_Toybox']
    """
    x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="()")
    x.append_details(array_to_append=x.attrib, detail_to_append=n)
    return x.attrib


def append_details_methods_test(n):
    # Doc test for class_grabber.get_method()
    """
    >>> append_details_methods_test("getBlock()")
    ['get_Block()']
    >>> append_details_methods_test("getInt()")
    ['get_Int()']
    >>> append_details_methods_test("getSum()")
    ['get_Sum()']
    >>> append_details_methods_test("getAvg()")
    ['get_Avg()']
    >>> append_details_methods_test("getOutput()")
    ['get_Output()']
    """
    x = class_grabberV2.ClassGrabber(new_class_name="some", new_data="")
    x.append_details(array_to_append=x.methods, detail_to_append=n)
    return x.methods


def add_under_test(n):

    """
    >>> add_under_test("getBlock()")
    'get_Block()'
    >>> add_under_test("getInt()")
    'get_Int()'
    >>> add_under_test("revOutput")
    'rev_Output'
    >>> add_under_test("getAverage()")
    'get_Average()'
    >>> add_under_test("toyBox")
    'toy_Box'
    """
    x = class_grabberV2.ClassGrabber(new_class_name="some", new_data=n)
    return x.add_under(n)


def check_ret_test(n):

    """
    >>> check_ret_test("getWall()")
    False
    >>> check_ret_test("getTarget()")
    False
    >>> check_ret_test("int getBlock()")
    True
    >>> check_ret_test("str getString()")
    True
    >>> check_ret_test("array getArray()")
    True
    >>> check_ret_test("getArray()")
    False

    """

    x = class_grabberV2.ClassGrabber(new_class_name="some", new_data=n)

    return x.check_ret(n)


def check_is_upper_test(ind, val):
    """

    >>> check_is_upper_test(1, "g")
    'g'
    >>> check_is_upper_test(0, "G")
    'g'
    >>> check_is_upper_test(1, "G")
    '_G'
    >>> check_is_upper_test(1, "k")
    'k'
    >>> check_is_upper_test(0, "K")
    'k'
    >>> check_is_upper_test(1, "K")
    '_K'
    """
    #
    x = class_grabberV2.ClassGrabber(new_class_name="", new_data="")
    return x.check_is_upper(index=ind, value=val)

# OUTPUT_INJECTION TESTS


def attrib_type_test(attrib):
    """

    >>> attrib_type_test(attrib="int row")
    'self.row = 0'

    >>> attrib_type_test(attrib="int col")
    'self.col = 0'

    >>> attrib_type_test(attrib="string x")
    "self.x = ''"

    >>> attrib_type_test(attrib="string y")
    "self.y = ''"

    >>> attrib_type_test(attrib="allMyToybox")
    'self.allmytoybox = []'
    >>> attrib_type_test(attrib="allMyPlayers")
    'self.allmyplayers = []'
    """
    output = []
    x = output_injection.OutputInjection()
    x.attrib_type(array=output, attrib=attrib)
    for data in output:
        return data.replace("\t\t", "")


def method_returns_test(method):
    """

    >>> method_returns_test("int getCol")
    'def get_col -> int:'
    >>> method_returns_test("int getGrid")
    'def get_grid -> int:'
    >>> method_returns_test("string getOutput")
    'def get_output -> string:'
    >>> method_returns_test("array getArr")
    'def get_arr -> array:'
    >>> method_returns_test("int getX")
    'def get_x -> int:'
    >>> method_returns_test("int getY")
    'def get_y -> int:'
    """
    grab = class_grabberV2.ClassGrabber(new_class_name="", new_data="")
    output = []
    x = output_injection.OutputInjection()
    x.method_returns(array=output, method=grab.add_under(n=method), method_to_run=grab.check_ret(method=method))
    for data in output:
        return data.replace("\t", "").replace("\n", "")

# LOADER TEST


def parse_uneeded_test(line):

    """
    >>> parse_uneeded_test('@enduml')
    True
    >>> parse_uneeded_test('some')
    False
    >>> parse_uneeded_test('body')
    False
    >>> parse_uneeded_test('once')
    False
    >>> parse_uneeded_test('told')
    False
    >>> parse_uneeded_test('me')
    False
    """
    x = loader.Loader(file="")
    return x.parse_uneeded(line=line)

def get_rel_test(line):

    """
    >>> get_rel_test("Tester *-- Toaster")
    True
    >>> get_rel_test("Tester <|-- Toaster")
    True
    >>> get_rel_test("Tester o-- Toaster")
    True
    >>> get_rel_test("Tester isa Toaster")
    False
    >>> get_rel_test("Tester wel Toaster")
    False

    """
    x = loader.Loader(file="")
    return x.get_rel(line=line)

if __name__ == "__main__":
    doctest.testmod()
