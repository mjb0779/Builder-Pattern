from abc import ABCMeta, abstractmethod


class AbstractFileValidator(metaclass=ABCMeta):

    def __init__(self, new_file):
        self.file = new_file

    def file_extension_check(self):
        pass

    def check_plant(self):
        pass

    def check(self):
        pass
