
class OutputInjection:

    def __init__(self):
        self.attrib_types = {
            "all": " = []",
            "int ": " = 0",
            "string ": " = ''"
        }

    def attrib_type(self, array, attrib):

        if attrib == "":
            array.append(attrib.replace("", "\n"))
        else:
            for key, value in self.attrib_types.items():
                if key in attrib:
                    if key != "all":
                        return array.append("\t\tself." + attrib.replace(key, "").lower() +  value)
                    else:
                        return array.append("\t\tself." + attrib.lower().replace("\n", "") + value)

    def method_returns(self, array, method, method_to_run):

        return_value = ""
        if method_to_run:
            r = method.split(" ")
            return_value = r[0]
            return array.append("\tdef " + r[1].lower() + " -> " + return_value + ":" + "\n")
        else:
            return_value = "None"
            return array.append("\tdef " + method.lower() + " -> " + return_value + ":" + " \n")

    def class_header(self, array, test, partner, class_name):

        class_header = "class " + class_name.replace("{", ":")
        if test:
            array.append(("import " + partner + "\n\n"))
            array.append(class_header)
            array.append("\tdef __init__(self, " + partner.lower() + ": " + partner + "):\n")
        else:
            array.append(class_header)
            array.append("\tdef __init__(self):\n")