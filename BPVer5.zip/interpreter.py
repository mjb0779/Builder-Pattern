import pkg_resources
import constant
import class_grabberV2
import txt_file_validator
import os.path
import loader
from array import *


class Interpreter(object):
    file = ''
    file_contents = []
    my_classes = []
    str = ''
    rel = []
    fin = ''
    partner = ''
    output = []

    def __init__(self, file):
        self.file = file
        self.dict = {}
        self.output = []



    # def read_file(self):
    #
    #     with open(self.file, "r") as file:
    #         contents = file.readlines()
    #         for line in contents[1:]:
    #             if line == '@startuml\n' or line == '@enduml':
    #                 continue  # Takes out the header and footer parts of the txt file
    #             if line == '\n':
    #                 continue  # Takes out the extra lines
    #             elif "*--" in line.split(" ") or "<|--" in line.split(" ") or "o--" in line.split(" "):
    #                 self.rel.append(line)
    #             else:
    #                 self.file_contents.append(line)  # only adds the vital information to the actual content array
    #
    #         return self.file_contents

    def data_parser(self):
        count = 0
        class_count = 0
        temp_str = ''
        temp_fin = ''
        for line in self.file_contents:

            if 'class' in line and '{\n':
                temp = line.split(' ')
                print(temp[1])
                self.my_classes.append(temp[1])
                class_count += 1
                count = 1
                continue
            elif '}\t\n' in line or '}\n' in line:
                count = 0

            if count == 1:
                temp_str += ''.join(line)
            else:
                self.fin = temp_str
                self.dict[self.my_classes[class_count - 1]] = self.fin

                temp_str = ''

        return self.dict

    def load(self):
        file_validate = txt_file_validator.TxtFileValidator(new_file=self.file)
        if file_validate.check():
            # self.read_file()
            # self.data_parser()
            # self.get_details()
            load = loader.Loader(self.file)
            self.file_contents = load.load_file()
            self.data_parser()
            self.rel = load.relArr
            self.get_details()
        else:
            raise Exception("Incorrect File")

    def get_rel(self, class_name):

        has_rel = False
        self.partner = ''

        for x in self.rel:
            tempx = x.split(" ")
            if class_name == tempx[2]:
                self.partner = tempx[0]
                has_rel = True
            else:
                has_rel = False

            if has_rel is True:
                break

        return has_rel

    def get_details(self):

        for x, y in self.dict.items():

            a_class = class_grabberV2.ClassGrabber(new_class_name=x, new_data=y)
            test = self.get_rel(a_class.class_name.replace("{", ""))

            if test:
                self.output.append(("import " + self.partner + "\n\n"))
                self.output.append("class " + a_class.class_name.replace("{", ":"))
                self.output.append("\tdef __init__(self, " + self.partner.lower() + ": " + self.partner + "):\n")
            else:
                self.output.append("class " + a_class.class_name.replace("{", ":"))
                self.output.append("\tdef __init__(self):\n\t")

            for line in a_class.attrib:
                if 'all' in line:
                    self.output.append("\t\tself." + line.lower() + " = []")
                elif 'int' in line:
                    self.output.append("\t\tself." + line.replace("int ", "").lower() + " = 0")
                elif line == "":
                    self.output.append(line.replace("", "\n"))
                else:
                    self.output.append("\t\tself." + line.lower())

            for line in a_class.methods:
                if a_class.check_ret(line):
                    r = line.split(" ")

                    self.output.append("\tdef " + r[1].lower() + " -> " + r[0] + ":")

                else:
                    a_class.return_val = "None"
                    self.output.append("\tdef " + line.lower() + " -> None:")

                self.output.append("\t\tpass \n\n")

            self.output.append("# =========================================================================\n")

        return self.output
