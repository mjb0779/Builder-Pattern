import my_view
import controllerV2


#
# a = 'READ.txt'
# a_file = InterpreterV4.Interpreter(a)
# a_file.load()
# a_input = input('Enter File: ')
a_input = "READ.txt"
cont = controllerV2.Controller(file= a_input)
cont.go()

cont.parse_data()

