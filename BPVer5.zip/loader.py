import docx


class Loader(object):

    file = ''

    def __init__(self, file):
        self.file = file
        self.file_contents = []
        self.rel = ["*--", "<|--", "o--"]
        self.relArr = []

    def load_file(self):
        name, separator, extension = self.file.partition(".")
        if extension == "txt":
            with open(self.file, "r") as file:
                contents = file.readlines()
                for line in contents[1:]:
                    if self.parse_uneeded(line=line):
                        continue
                    elif self.get_rel(line=line):
                        self.relArr.append(line)
                    else:
                        self.file_contents.append(line)
        elif extension == "docx":
            doc = docx.Document(self.file)
            for para in doc.paragraphs:
                if self.parse_uneeded(para.text):
                    continue
                elif self.get_rel(para.text):
                    self.relArr.append(para.text)
                else:
                    self.file_contents.append(para.text)

        return self.file_contents

    def parse_uneeded(self, line):

        start = '@startuml'
        end = "@enduml"
        if start in line or end in line or line == "\n":
            return True

        return False

    def get_rel(self, line):

        temp = line.split(" ")
        if temp.__len__() == 3:
            if temp[1] in self.rel:
                return True

        return False
