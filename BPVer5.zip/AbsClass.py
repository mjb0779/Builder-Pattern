from abc import ABCMeta, abstractmethod


class AbsClass(metaclass=ABCMeta):

	def __init__(self):

		self.all_my_id = []

	@abstractmethod
	def get_details(self) -> str:
		pass

	@abstractmethod
	def get_id(self) -> int:
		pass

	