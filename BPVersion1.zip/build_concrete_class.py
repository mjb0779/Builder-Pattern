import abstract_class_builder

class BuildConcretes(abstract_class_builder.ClassBuilder):

    def __init__(self):
        super().__init__()

    def get_details(self, data):
        self.data = data

    def create_class(self, class_name):
        self.file = open(class_name, "w+")

    def create_constructor(self, const_data):
        self.file.write(const_data)

    def create_methods(self, methods_data):
        self.file.write(methods_data)

    def read(self):
        count = 0
        for line in self.data:
            if count == 1:
                self.file.write(line)
            else:
                if "class" in line:
                    temp = line.split(" ")
                    self.create_class(temp[1])
                    self.file.write(line)
                elif "__init__" in line:
                    self.create_constructor(line)
                    count = 1
                elif line == '\n':
                    count = 0
                elif "()" in line:
                    self.create_methods(line)
                    self.file.write("\t# Code that the method implements")

