from cmd import Cmd
import sys
import file_validator
import controllerV2
import my_view
import os


class Output(Cmd):

    def __init__(self):
        Cmd.__init__(self)
        self.intro = "Welcome to UML Interpreter.   Press help or ? for command list"
        self.prompt = ">>>"
        self.view = my_view.View()

    def do_load(self, file):
        """load [file]
        Load the named file's data """

        if file:
            a_cont = controllerV2.Controller(file=file)
        else:
            self.view.say("You Have not specified a file")

    def do_path(self, path):
        """path [path]
        Specifying file path"""
        if os.path.isdir(path):
            os.chdir(path)
            files = os.listdir(path)
            for name in files:
                self.view.say(name)
        else:
            self.view.say("File path not found")

    def do_check(self, file):
        """check [file]
        Check the named file's validity """
        if file:
            a_fvalidator = file_validator.FileValidator(file)
            if a_fvalidator.check():
                self.view.say("File is Valid for Interpreting")
            else:
                self.view.say("File is not of correct format or may not be of PlantUML")
        else:
            self.view.say("You Have not specified a file")

    def do_bye(self, arg):
        """Close program"""
        return True


if __name__ == '__main__':
    Output().cmdloop()
