from abc import ABCMeta, abstractmethod

class AbsClass(metaclass=ABCMeta):
	def __init__(self):
		self.all_my_id = []
	def get_details() -> str:
		pass
	def get_id() -> int:
		pass
	