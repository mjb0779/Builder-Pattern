import controllerV2


class Director(object):

    def __init__(self, builder, file):
        self.data = file
        self.builder = builder
        # self.dictionary = {}
        # self.controller = controllerV2.Controller(file)

    def set_builder(self, new_builder):
        self.builder = new_builder

    # def parse_file(self):
    #     self.data = self.controller.go()
    #     count = 0
    #     for line in self.data:
    #         self.dictionary[count+1] = line
    #
    # def show_classes(self):
    #     for x, y in self.dictionary.items():
    #         self.controller.view.say(x, ": ", y)

    def give_details(self):
        self.builder.get_details(self.data)
        self.builder.read()