import interpreter
import interpreterV5
import my_view
import Director
import build_abstruct_class
import build_concrete_class


class Controller:

    def __init__(self, file):
        self.view = my_view.View()
        self.x = file
        self.output = []
        self.go()

    def go(self):
        load = interpreterV5.Interpreter(self.x)
        load.load()
        temp = ''
        for item in load.output:
            temp += item

        self.output = temp.split("# =========================================================================")



    def parse_data(self):
        for line in self.output:
             if "(metaclass=ABCMeta)" in line :
                 self.view.say(">> Abstract Classes")
                 abs = build_abstruct_class.BuildAbstructs()
                 director = Director.Director(builder=abs, file=line)
                 director.give_details()
                 self.view.say(abs.get_result())
             else:
                 conc = build_concrete_class.BuildConcretes()
                 director = Director.Director(builder=conc, file=line)
                 director.give_details()
                 self.view.say(conc.get_result())