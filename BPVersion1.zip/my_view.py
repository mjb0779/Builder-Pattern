class View:

    def say(self, new_message):
        print(new_message)

    def get_input(self, prompt):
        x = input(prompt)
        return x