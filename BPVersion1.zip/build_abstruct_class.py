import abstract_class_builder

class BuildAbstructs(abstract_class_builder.ClassBuilder):

    def __init__(self):
        super().__init__()


    def get_details(self, data):
        self.data = data
        self.get_class_name()

    def get_class_name(self):
        temp = self.data.split(" ")
        for line in temp:
            if "ABCMeta" in line:
                cls = line.split("(")
                self.class_name = cls[0]

    def create_methods(self, f, methods_data):
        meth = methods_data.replace("\n", "") + "\n\t\tpass\n\t"
        f.write(meth)
        self.result += meth
    def read(self):
        count = 0
        f = open(self.class_name+".py", 'w+')
        f.write("from abc import ABCMeta, abstractmethod\n\n")
        temp = self.data.split("\n\t")
        for line in temp:
            if "->" in line:
                self.create_methods(f, line)
            else:
                self.result += line + "\n\t"
                f.write(line + "\n\t")
        f.close()
